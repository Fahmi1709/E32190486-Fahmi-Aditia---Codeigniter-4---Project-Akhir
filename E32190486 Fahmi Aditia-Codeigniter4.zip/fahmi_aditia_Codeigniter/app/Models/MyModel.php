<?php

namespace App\Models;

use CodeIgniter\Model;

class MyModel extends Model
{
    protected $table      = 'masuk';
    protected $useTimestamps = true;
    protected $allowedFields = ['namadepan', 'namabelakang', 'username', 'password', 'alamat'];

    public function getMy($id = false)
    {
        if ($id === false) {
            return $this->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
}
