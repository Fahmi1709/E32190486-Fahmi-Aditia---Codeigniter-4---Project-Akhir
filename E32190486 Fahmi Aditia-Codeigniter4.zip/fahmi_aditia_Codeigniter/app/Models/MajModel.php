<?php

namespace App\Models;

use CodeIgniter\Model;

class MajModel extends Model
{
    protected $table      = 'majalah';
    protected $useTimestamps = true;

    public function getMajalah($id = false)
    {
        if ($id === false) {
            return $this->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
}
