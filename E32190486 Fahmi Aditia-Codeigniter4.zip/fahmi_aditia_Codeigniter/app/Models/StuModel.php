<?php

namespace App\Models;

use CodeIgniter\Model;

class StuModel extends Model
{
    protected $table      = 'studio';
    protected $useTimestamps = true;
    protected $allowedFields = ['namakarya', 'namaseniman', 'bahan', 'ukuranasli', 'gambar'];

    public function getStu($id = false)
    {
        if ($id === false) {
            return $this->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
}
