<?php

namespace App\Models;

use CodeIgniter\Model;

class GalModel extends Model
{
    protected $table      = 'galeri';
    protected $useTimestamps = true;

    public function getGaleri($id = false)
    {
        if ($id === false) {
            return $this->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
}
