<?php

namespace App\Controllers;

use App\Models\StuModel as StuModel;

class Stu extends BaseController
{
    protected $StuModel;
    public function __construct()
    {
        $this->StuModel = new StuModel();
        helper('form');
    }
    public function index()
    {
        $data = [
            'studio' => $this->StuModel->getStu(),
        ];
        return view('/studio', $data);
    }
    public function stu()
    {
        $file_gambar = $this->request->getFile('gambar');
        $file_gambar->move(ROOTPATH . 'public/img/user');

        $data = [
            'namakarya' => $this->request->getVar('namakarya'),
            'namaseniman' => $this->request->getVar('namaseniman'),
            'bahan' => $this->request->getVar('bahan'),
            'ukuranasli' => $this->request->getVar('ukuranasli'),
            'gambar' => $file_gambar->getName(),
        ];
        $this->StuModel->save($data);
        return redirect()->to('/Stu');
    }


    //--------------------------------------------------------------------

}
