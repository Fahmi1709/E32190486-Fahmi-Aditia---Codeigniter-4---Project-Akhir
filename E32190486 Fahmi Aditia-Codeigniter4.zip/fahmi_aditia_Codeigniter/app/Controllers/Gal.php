<?php

namespace App\Controllers;


use App\Models\GalModel as ModelsGalModel;

class Gal extends BaseController
{
    protected $galModel;
    public function __construct()
    {
        $this->galModel = new ModelsGalModel();
    }
    public function index()
    {
        $data = [
            'judul' => 'judul',
            'galeri' => $this->galModel->getGaleri()
        ];
        return view('/galeri', $data);
    }


    //--------------------------------------------------------------------

}
