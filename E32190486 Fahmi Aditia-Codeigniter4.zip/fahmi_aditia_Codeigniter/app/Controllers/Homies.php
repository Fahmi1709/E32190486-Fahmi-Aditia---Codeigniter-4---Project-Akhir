<?php

namespace App\Controllers;

use App\Models\majModel;
use App\Models\MajModel as ModelsMajModel;

class Homies extends BaseController
{
    public function index()
    {
        return view('/homies');
    }


    //--------------------------------------------------------------------

}
