<?php

namespace App\Controllers;

use App\Models\MasukModel as MasukModel;
use App\Models\MyModel as Mymodel;
use App\Database;
use CodeIgniter\HTTP\Request;
use App\Models\LoginModel as LoginModel;

class Masuk extends BaseController
{
    protected $Mymodel;
    protected $loginModel;

    public function __construct()
    {
        $this->Mymodel = new Mymodel();
        $this->loginModel = new LoginModel();
    }
    public function index()
    {
        return view('/myhome');
    }
    public function login()
    {
        return view('/Pages/login');
    }

    public function signup()
    {
        return view('/Pages/signup');
    }

    public function berhasil()
    {
        return view('/Pages/berhasil');
    }

    public function gagal()
    {
        return view('/Pages/gagallogin');
    }

    public function my()
    {
        $data = [
            'namadepan' => $this->request->getVar('namadepan'),
            'namabelakang' => $this->request->getVar('namabelakang'),
            'username' => $this->request->getVar('email'),
            'password' => $this->request->getVar('password'),
            'alamat' => $this->request->getVar('alamat'),
        ];
        $this->Mymodel->save($data);
        return redirect()->to('/masuk/berhasil');
    }

    public function loginsistem()
    {

        $username = $this->request->getPost('email');
        $password = $this->request->getPost('password');


        $cek = $this->loginModel->cek_login($username, $password);
        if (($cek['username'] == $username && $cek['password'])) {
            session()->set('username', $cek['username']);
            session()->set('password', $cek['password']);
            session()->set('namadepan', $cek['namadepan']);
            session()->set('namabelakang', $cek['namabelakang']);
            session()->set('created_at', $cek['created_at']);
            session()->set('updated_at', $cek['updated_at']);
            return redirect()->to(base_url('/gal'));
        } else {
            return redirect()->to(base_url('/masuk/gagal'));
        }
    }


    //--------------------------------------------------------------------

}
