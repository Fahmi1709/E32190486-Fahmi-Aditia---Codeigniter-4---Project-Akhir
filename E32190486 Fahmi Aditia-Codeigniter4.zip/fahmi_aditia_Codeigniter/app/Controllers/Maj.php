<?php

namespace App\Controllers;

use App\Models\majModel;
use App\Models\MajModel as ModelsMajModel;

class Maj extends BaseController
{
    protected $majModel;
    public function __construct()
    {
        $this->majModel = new ModelsMajModel();
    }
    public function index()
    {
        $data = [
            'judul' => 'judulMajalah',
            'majalah' => $this->majModel->getMajalah()
        ];
        return view('/majalah', $data);
    }


    //--------------------------------------------------------------------

}
