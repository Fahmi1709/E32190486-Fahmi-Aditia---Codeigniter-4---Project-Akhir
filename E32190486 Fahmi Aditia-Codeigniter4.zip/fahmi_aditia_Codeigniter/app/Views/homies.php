<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Majalah</title>
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css" />
    <link rel="stylesheet" href="/css/custom-css-fahmi.css" />

    <style>
        hr {
            background-color: white;
        }

        .card-fahmi {
            position: relative;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark warna-background sticky-top">
        <a class="navbar-brand" href="#">Majalah</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/homies') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/gal') ?>">Galeri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/maj') ?>">Majalah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/stu') ?>">Studio</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid warna-background ukuran-100vh">
        <div class="row">
            <div class="col-md-6" style="margin-top: 200px;">
                <h1 style="text-align: center; color: white; font-size: 50px">"Creativity is contagious pass it on"</h1>
                <p style="text-align: center; color: white;">Albert Einstein</p>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top: 40px;">
        <div class="row">
            <div class="col-md-4 ukuran-70vh mt-5">
                <div class="card card-fahmi ukuran-60vh" style="width: 18rem;">
                    <img src="img/image823.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Majalah</h5>
                        <p class="card-text">Bacalah berita-berita mengenai yang terjadi di dunia seni</p>
                        <a href="<?= base_url('/maj') ?>" class="btn btn-danger warna-background border-0">Lanjut</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ukuran-70vh mt-5">
                <div class="card card-fahmi ukuran-60vh" style="width: 18rem;">
                    <img src="img/image840.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Studio</h5>
                        <p class="card-text">Simpan foto karya anda agar dapat dinikmati setiap saat</p>
                        <a href="<?= base_url('/stu') ?>" class="btn btn-danger warna-background border-0">Lanjut</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ukuran-70vh mt-5">
                <div class="card card-fahmi ukuran-60vh" style="width: 18rem;">
                    <img src="/img/image861.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Galeri</h5>
                        <p class="card-text">Nikmatilah karya seni dari seniman-seniman dunia</p>
                        <a href="<?= base_url('/gal') ?>" class="btn btn-danger warna-background border-0">Lanjut</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-xl-5">
        <div class="row">
            <div class="col-md-8">
                <h1 style="font-size: 100px;">Seni</h1>
                <p style="font-size: 27px;">
                    Seni adalah keahlian membuat karya yang bermutu (dilihat dari segi kehalusannya, keindahannya,
                    fungsinya, bentuknya, makna dari bentuknya, dan sebagainya), seperti tari, lukisan, ukiran. Seni
                    meliputi banyak kegiatan manusia dalam menciptakan karya visual, audio, atau pertunjukan yang
                    mengungkapkan imajinasi, gagasan, atau keperigelan teknik pembuatnya, untuk dihargai keindahannya
                    atau
                    kekuatan emosinya. Kegiatan-kegiatan tersebut pada umumnya berupa penciptaan karya seni,
                    kritik
                    seni, kajian sejarah seni dan estetika seni.<br>
                    <a href="https://id.wikipedia.org/wiki/Seni" style="color: red; text-decoration: none;">Wikipedia</a>
                </p>
            </div>
            <div class="col-md-3"></div>
            <div class="col-md-1 warna-background" style="border-radius: 50px;"></div>
        </div>
    </div>
    <div class="container ukuran-30vh"></div>
    <div class="container-fluid warna-background">

        <div class="row">
            <div class="col-md-4" style="height: 200px;">
                <h1 class="putih">Terima Kasih</h1>
                <p style="font-size: 20px;" class="putih">
                    Semoga karya seni yang kami suguhi dapat menginspirasi anda serta
                </p>
                <img src="/img/icons/envelope-open-line.png" alt="" height="40px" />
            </div>
            <div class="col-md-6" style="height: 200px;">
                <h1 class="putih">Alamat</h1>
                <p class="putih">
                    Jl. Kenanga, Patokan, Situbondo, Jawa Timur, Indonesia
                </p>
                <p class="putih">(+62) 8383-323-0652</p>
                <p class="putih">fahmiaditia53@gmail.com</p>
            </div>
            <div class="col-md-2">
                <img src="/img/logo.png" alt="" srcset="" width="170px" style="margin-top: 30px;" />
                <a href="/masuk" style="color: white;">Logout</a>
            </div>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>
    <script>
        function tombolKendali(halaman) {
            window.location.href = halaman;
        }
    </script>
</body>

</html>