<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Majalah</title>
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css" />
    <link rel="stylesheet" href="/css/custom-css-fahmi.css" />

    <style>
        .ada-apa {
            text-align: center;
            color: white;
        }

        hr {
            background-color: white;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark warna-background sticky-top">
        <a class="navbar-brand" href="#">Majalah</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/homies') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/gal') ?>">Galeri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/maj') ?>">Majalah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/stu') ?>">Studio</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid warna-background">
        <div class="container bg-transparent ukuran-50vh">
            <div class="jumbotron jumbotron-fluid bg-transparent">
                <div class="container">
                    <h1 class="display-4 ada-apa">Ada apa dengan seni ?</h1>
                    <p class="lead ada-apa">
                        Temukan info panas mengenai dunia seni
                    </p>
                </div>
            </div>
        </div>

        <!--lini berita-->
        <?php foreach ($majalah as $mj) : ?>
            <div class="container">
                <div class="container bg-light" style="border-radius: 10px; margin-bottom: 30px;">
                    <div class="row">
                        <div class="col">
                            <h4 style="font-weight: bold; margin: 10px;">Berita Galeri</h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col ukuran-50vh bg-danger" style="background-image:url('/gambarMajalah/<?= $mj['gambar'] ?>');background-size:cover; background-repeat: no-repeat;">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="margin-top: 10px;">
                            <h3 style="font-size: 40px;"><?= $mj['judul'] ?></h3>
                        </div>
                    </div>
                    <button type="button" class="btn warna-background putih" style="margin-top: 10px; margin-bottom: 10px;" onclick="tombolKendali('<?= $mj['alamat'] ?>')">Lanjut</button>
                </div>
                <hr>
            </div>
        <?php endforeach; ?>





        <div class="container">
        </div>
        <div class="container-fluid warna-background">
            <div class="row">
                <div class="col-md-4" style="height: 200px;">
                    <h1 class="putih">Terima Kasih</h1>
                    <p style="font-size: 20px;" class="putih">
                        Semoga berita seni yang kami suguhi dapat menginspirasi anda
                    </p>
                    <img src="/img/icons/envelope-open-line.png" alt="" height="40px" />
                </div>
                <div class="col-md-6" style="height: 200px;">
                    <h1 class="putih">Alamat</h1>
                    <p class="putih">
                        Jl. Kenanga, Patokan, Situbondo, Jawa Timur, Indonesia
                    </p>
                    <p class="putih">(+62) 8383-323-0652</p>
                    <p class="putih">fahmiaditia53@gmail.com</p>
                </div>
                <div class="col-md-2">
                    <img src="/img/logo.png" alt="" srcset="" width="170px" style="margin-top: 30px;" />
                    <a href="/masuk" style="color: white;">Logout</a>
                </div>
            </div>
        </div>



        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
        </script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
        </script>
        <script>
            function tombolKendali(halaman) {
                window.location.href = halaman;
            }
        </script>
</body>

</html>