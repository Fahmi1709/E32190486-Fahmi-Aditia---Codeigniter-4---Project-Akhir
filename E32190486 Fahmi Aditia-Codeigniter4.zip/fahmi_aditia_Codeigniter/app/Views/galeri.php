<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Galeri</title>
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css" />
    <link rel="stylesheet" href="/css/custom-css-fahmi.css" />
    <style>
        .para {
            background-image: url("img/alex-mihis-KptlGNWqnQY-unsplash.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .my-header {
            background-image: url("img/pajangan/abstract-1867935_1280.jpg");
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark warna-background sticky-top">
        <a class="navbar-brand" href="#">Majalah</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/homies') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/gal') ?>">Galeri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/maj') ?>">Majalah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/stu') ?>">Studio</a>
                </li>
            </ul>
        </div>
    </nav>

    <!--header ukiran bunga-->
    <div class="container-fluid ukuran-60vh my-header">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h1 class="putih mt-5" style="font-size: 70px;">Temukan Dirimu</h1>
                    <p class="putih">Seni merupakan sebuah cerminan jiwa</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container bg-dark warna-background" style="transform: translateY(-40px);">
        <div class="row">
            <div class="col">
                <h1 style="text-align: center; color: white;">
                    “Creativity takes courage”
                </h1>
                <h5 style="text-align: center; color: white;">Henri Matisse</h5>
            </div>
        </div>
    </div>
    <!--header ukiran bunga-->

    <!--inti galeri-->
    <div class="container">
        <!--card-->
        <div class="card-columns">
            <?php foreach ($galeri as $gl) : ?>
                <div class="card">
                    <img src="/img/pajangan/<?= $gl['gambar']; ?>" class="card-img-top" alt="..." />
                    <div class="card-body">
                        <h5 class="card-title"><?= $gl['judul']; ?></h5>
                        <p class="card-text"><?= $gl['teks']; ?></p>
                        <p class="card-text">
                            <small class="text-muted">Hari ini : <?= date('Y/m/d H:i:s'); ?></small>
                        </p>
                        <button class="btn info-lanjut" onclick="tombolKendali('<?= $gl['link']; ?>')">Info Lanjut</button>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
        <!--card-->
    </div>


    <div class="container ukuran-50vh para">
        <div class="row">
            <img src="/img/galeriSeniLogoPutih.png" alt="" srcset="" height="200px" style="margin: 40px;" />
        </div>
    </div>
    <div class="container">
        <hr />
    </div>
    <div class="container-fluid warna-background">
        <div class="row">
            <div class="col-md-4" style="height: 200px;">
                <h1 class="putih">Terima Kasih</h1>
                <p style="font-size: 20px;" class="putih">
                    Semoga karya seni yang kami suguhi dapat menginspirasi anda
                </p>
                <img src="/img/icons/envelope-open-line.png" alt="" height="40px" />
            </div>
            <div class="col-md-6" style="height: 200px;">
                <h1 class="putih">Alamat</h1>
                <p class="putih">
                    Jl. Kenanga, Patokan, Situbondo, Jawa Timur, Indonesia
                </p>
                <p class="putih">(+62) 8383-323-0652</p>
                <p class="putih">fahmiaditia53@gmail.com</p>
            </div>
            <div class="col-md-2">
                <img src="/img/logo.png" alt="" srcset="" width="170px" style="margin-top: 30px;" />
                <a href="/masuk" style="color: white;">Logout</a>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
        function tombolKendali(halaman) {
            window.location.href = halaman;
        }
    </script>
</body>

</html>