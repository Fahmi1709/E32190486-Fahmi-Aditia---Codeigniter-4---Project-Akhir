<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Studio</title>
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css" />
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css" />
    <link rel="stylesheet" href="/css/custom-css-fahmi.css" />
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark warna-background sticky-top">
        <a class="navbar-brand" href="#">Majalah</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/homies') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/gal') ?>">Galeri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/maj') ?>">Majalah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/stu') ?>">Studio</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid warna-background ukuran-50vh">
        <div class="row">
            <div class="col-md-5">
                <h1 style="text-align: center; color: white; margin-top: 100px; font-size: 50px;">Bangun studio anda
                </h1>
                <p style="text-align: center; color: white;">Anda dapat menyimpan photo karya seni anda</p>
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
    <div class="container">
        <div class="alert alert-warning" role="alert">
            <h4 class="alert-heading">Kebijakan kami</h4>
            <p>File gambar yang anda upload dapat dilihat oleh pengunjung lain dan <br>kami tidak akan
                menggunakan file yang anda upload.</p>
            <hr>
            <p class="mb-0">Semua file yang anda upload, akan disimpan dan dipajang pada halaman ini</p>
        </div>
    </div>
    <div class="container" style="margin-top: 100px; margin-bottom: 40px;">
        <div class="row">
            <div class="col">
                <h1>Simpan Photo Karya Seni Anda</h1>
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
    <div class="container">
        <div class="row">
            <div class="col">
                <?= form_open_multipart(base_url('/Stu/stu')); ?>
                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label for="namakarya">Nama Karya</label>
                        <input type="text" class="form-control" id="namakarya" required name="namakarya">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="namaseniman">Nama Seniman</label>
                        <input type="text" class="form-control" id="namaseniman" required name="namaseniman">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label for="bahan">Media</label>
                        <input type="text" class="form-control" id="bahan" required placeholder="contoh : canvas" name="bahan">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="ukuranasli">Ukuran Asli</label>
                        <input type="text" class="form-control" id="ukuranasli" required placeholder="contoh : 2x1 m" name="ukuranasli">
                    </div>
                </div>
                <div class="form-group">
                    <label for="gambar">Masukkan file anda (resolusi maksimal 1300px dan ukuran maksimal 1,5 mb)</label>
                    <input type="file" class="form-control-file" id="gambar" name="gambar">
                </div>
                <div class="form-group">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                        <label class="form-check-label" for="invalidCheck2">
                            Saya setuju dengan kebijakan Galeri Seni
                        </label>
                    </div>
                </div>
                <button class="btn btn-danger" type="submit">Upload</button>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
    <div class="container warna-background" style="border-radius: 50px; height: 100px; margin-top: 70px;">
        <div class="row">
            <div class="col">
                <h1 style="text-align: center; color: white; margin-top: 20px;">Karya Anda</h1>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top: 50px;">
        <div class="card-columns">
            <?php foreach ($studio as $st) : ?>
                <div class="card">
                    <img src="/img/user/<?= $st['gambar'] ?>" class="card-img-top" alt="..." style="border: 1px solid rgb(255, 72, 0);">
                    <div class="card-body">
                        <p class="card-text" style="font-size: 30px;"><?= $st['namakarya']; ?></p>
                        <p class="card-text">Seniman : <?= $st['namaseniman']; ?></p>
                        <p class="card-text">Bahan : <?= $st['bahan']; ?></p>
                        <p class="card-text">Ukuran : <?= $st['ukuranasli']; ?></p>
                        <small>
                            <p class="card-text">Upload : <?= $st['created_at']; ?></p>
                        </small>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
    </div>
    <div class="container-fluid warna-background">
        <div class="row">
            <div class="col-md-4" style="height: 200px;">
                <h1 class="putih">Terima Kasih</h1>
                <p style="font-size: 20px;" class="putih">
                    Semoga berita seni yang kami suguhi dapat menginspirasi anda
                </p>
                <img src="/img/icons/envelope-open-line.png" alt="" height="40px" />
            </div>
            <div class="col-md-6" style="height: 200px;">
                <h1 class="putih">Alamat</h1>
                <p class="putih">
                    Jl. Kenanga, Patokan, Situbondo, Jawa Timur, Indonesia
                </p>
                <p class="putih">(+62) 8383-323-0652</p>
                <p class="putih">fahmiaditia53@gmail.com</p>
            </div>
            <div class="col-md-2">
                <img src="/img/logo.png" alt="" srcset="" width="170px" style="margin-top: 30px;" />
                <a href="/masuk" style="color: white;">Logout</a>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>
    <script>
        function tombolKendali(halaman) {
            window.location.href = halaman;
        }
    </script>
</body>

</html>