<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap.css" />
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap-grid.css" />
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css" />
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css" />
    <link rel="stylesheet" href="/css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css" />
    <style>
        .my-col {
            margin-top: 300px;
        }
    </style>
    <link rel="stylesheet" href="/css/custom-css-fahmi.css" />

    <div class="container-fluid warna-background ukuran-100vh">
        <div class="row">
            <div class="col my-col">
                <h1 class="putih" style="text-align: center; font-size: 50px">Email atau password anda salah silahkan login kembali</h1>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p style="text-align: center; font-weight: bold;">Kembali ke <a href="<?= base_url('/masuk/login') ?>" style="text-align: center; text-decoration: none;" class="putih">login</a></p>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    </body>

</html>