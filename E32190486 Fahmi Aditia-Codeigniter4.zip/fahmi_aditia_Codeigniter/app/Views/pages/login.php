<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <style>
        .fahmi-container {
            height: 80vh;
        }

        .testing {
            height: 100px;
        }

        .picture-container {
            background-image: linear-gradient(to right, rgb(255, 42, 0), rgb(219, 0, 73));
            background-size: cover;
            background-repeat: no-repeat;
            padding: 120px;
        }

        .login-container h1 {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            position: relative;
        }

        .logo {
            height: 200px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            position: relative;
        }

        .custom-container {
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 5px 5px 10px rgb(189, 189, 189);
        }

        @media screen and (max-width: 1000px) {
            .login-container {
                height: 90vh;
            }

            .login-container h1 {
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                position: relative;
            }

            #kata-kata {
                display: none;
            }

            .custom-container {
                margin-top: 0;
            }

        }
    </style>

    <title>Galeri Seni Login Page</title>
</head>

<body>
    <div class="container custom-container">
        <div class="row">
            <div class="col-lg-6 picture-container">
                <img src="<?= base_url('img/galeriSeniLogoPutih.png'); ?>" alt="logo" class="logo">
            </div>
            <div class="col-lg-6 login-container">
                <div class="row">
                    <h1 style="margin-top: 80px; color: rgb(255, 1, 98);"><strong>Login</strong></h1>
                    <p style="text-align: center; font-size: 20px;" id="kata-kata">Selamat datang di Galeri Seni, Silahkan masuk terlebih dahulu untuk menikmati karya seni kami</p>
                    <br>
                    <hr>
                </div>
                <div class="row">
                    <div class="container">
                        <form action="/Masuk/loginsistem" method="post">
                            <div class="form-group">
                                <label for="email">Alamat Email</label>
                                <input type="text" class="form-control" id="email" placeholder="email@contoh.com" name="email">
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="dropdownCheck">
                                    <label class="form-check-label" for="dropdownCheck">
                                        Remember me
                                    </label>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-block text-light" style="border-radius: 30px; background-color: rgb(255, 1, 98)">Masuk</button>
                            <br>
                            <p style="text-align: center;">belum memiliki akun? <a href="<?= base_url('/masuk/signup'); ?>" style="color: rgb(255, 1, 98);">Daftar</a><br>Atau kembali ke <a href="<?= base_url('/masuk') ?>" style="color: rgb(255, 1, 98);">Home</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>