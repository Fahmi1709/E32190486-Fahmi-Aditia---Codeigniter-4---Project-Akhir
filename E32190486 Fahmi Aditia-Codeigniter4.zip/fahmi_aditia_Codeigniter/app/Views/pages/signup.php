<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.css">
    <link rel="stylesheet" href="css/bootstrap-4.0.0-dist/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <style>
        .fahmi-container {
            height: 80vh;
        }

        .testing {
            height: 100px;
        }

        .picture-container {
            background-image: linear-gradient(to right, rgb(255, 42, 0), rgb(219, 0, 73));
            background-size: cover;
            background-repeat: no-repeat;
            padding: 120px;
        }

        .login-container h1 {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            position: relative;
        }

        .logo {
            height: 200px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            position: relative;
        }

        .custom-container {
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 5px 5px 10px rgb(189, 189, 189);
        }

        @media screen and (max-width: 1000px) {
            .login-container {
                height: 120vh;
            }

            .login-container h1 {
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                position: relative;
            }

            #kata-kata {
                margin-left: 200px;
                display: none;
            }

            .custom-container {
                margin-top: 0;
            }

        }
    </style>

    <title>Galeri Seni Sign Up Page</title>
</head>

<body>
    <div class="container custom-container">
        <div class="row">
            <div class="col-lg-6 picture-container">
                <img src="<?= base_url('img/galeriSeniLogoPutih.png'); ?>" alt="logo" class="logo">
            </div>
            <div class="col-lg-6 login-container">
                <div class="row">
                    <h1 style="margin-top: 80px; color: rgb(255, 1, 98);"><strong>Daftar</strong></h1>
                    <p style="text-align: center; font-size: 20px; margin-left: 60px;" id="kata-kata">Anda dapat mengisi form berikut ini terlebih dahulu</p>
                    <br>
                    <hr>
                </div>
                <div class="row">
                    <div class="container">
                        <form action="/masuk/my" method="POST">
                            <?= csrf_field(); ?>
                            <div class="form-row">
                                <div class="col">
                                    <label for="namadepan">Nama Depan</label>
                                    <input type="text" class="form-control" placeholder="" id="namadepan" name="namadepan">
                                </div>
                                <div class="col">
                                    <label for="namabelakang">Nama Belakang</label>
                                    <input type="text" class="form-control" placeholder="" id="namabelakang" name="namabelakang">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="email">Email</label>
                                    <input type="text" class="form-control" id="email" name="email">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control" id="alamat" placeholder="" name="alamat">
                            </div>
                            <button type="submit" class="btn btn-block" style="background-color: rgb(255, 1, 98); border-radius: 30px; color: white; margin-bottom: 20px; margin-top: 20px;">Daftar</button>
                        </form>
                        <p style="text-align: center;">Sudah memiliki akun? <a href="<?= base_url('/masuk/login'); ?>" style="color: rgb(255, 1, 98);">Masuk</a><br>atau kembali ke <a href="<?= base_url('/masuk') ?>" style="color: rgb(255, 1, 98);">Home</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>